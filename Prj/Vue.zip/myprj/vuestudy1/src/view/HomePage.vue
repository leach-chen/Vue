<template>
    <div style="background-color:#EAEAEA;width:100%;height:100%;">
      <homehead/>
      <div class="home-banner">
        <div class="text-top">会员 【我的二维码】</div>
        <div class="middle-content">

            <img src="../assets/img/member_self_image@2x.png">
            <div class = "middle_text">
                <div>0</div>
                <div class="middle_text1">积分</div>
            </div>

        </div>
      </div>

      
      <div class="item-content">
        <div class="item-child" v-for="item in dataList" :key="item.iconurl">
            <img class ="item-child-icon" :src="item.iconurl" />
            <!-- src="../assets/img/member_sign_in@2x.png" -->
            <p class ="item-child-tv">{{item.showtv}}</p>
        </div>
      </div>
    </div>
</template>


<script>
import homehead from "../components/head"

export default {
    name:"home",
    components: {homehead},
    data(){
      return{ dataList:[
        {iconurl:require("../assets/img/member_sign_in@2x.png"),showtv:"每日签到"},
        {iconurl:require("../assets/img/member_order@2x.png"),showtv:"全部订单"},
        {iconurl:require("../assets/img/member_personal_data@2x.png"),showtv:"个人资料"},
        {iconurl:require("../assets/img/member_card@2x.png"),showtv:"会员积分卡"},
        {iconurl:require("../assets/img/member_reserve_record@2x.png"),showtv:"预订记录"},
        {iconurl:require("../assets/img/member_reserve@2x.png"),showtv:"我要预订"},
        {iconurl:require("../assets/img/member_guagua_card@2x.png"),showtv:"刮刮卡"},
        {iconurl:require("../assets/img/member_discount_coupon@2x.png"),showtv:"优惠券"},
        {iconurl:require("../assets/img/member_sign_in@2x.png"),showtv:"储值专区"},
        {iconurl:require("../assets/img/member_big_plate@2x.png"),showtv:"大转盘"},
        {iconurl:require("../assets/img/member_mine_number@2x.png"),showtv:"我的排号"}
      ]
      }
    }
}
</script>

<style  lang="less" scoped>

.home-banner
{
    width: 100%;
    height: 170px;
    background: url("../assets/img/member_background_image@2x.png");
    background-repeat: no-repeat;
    background-size:cover;
    background-position: center center;
    padding-top: 1px;
}

.text-top
{
    margin-left: 100px;
  
    color: #fff;
    font-size: 16px;
    text-align: top;
    line-height: 45px;
}

.middle-content
{
  width: 100%;
  height: 76px;
  background-color: #000;
  margin-top: 10px;
  display: flex;
  opacity: 0.5; 
}

.middle-content img
{
  margin-left: 17px;
  width: 76px;
}

.middle_text
{
 
  height: 100%;
  display: flex;
  flex-direction:column;
  justify-content:center;
  text-align: center;
}
.middle_text div
{
  color: #fff;
  margin-left: 60px;
}

.middle_text1
{
  margin-top: 10px;
}

.item-content
{
  width: 100%;
  display: flex;
  flex-direction:row;
  flex-wrap: wrap;
  margin-top: 5px;
  text-align: center;
}




.item-child
{
  background-color: #fff;
  width: 33.25555555555555%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  text-align: center;
  align-items:center;
  border-right:1px solid #EAEAEA;
  border-bottom:1px solid #EAEAEA;
}

@media only screen and (max-width: 768px) {
    .item-child
    {
      width: 33%;
    }
}


.item-child-icon
{
  width: 36px;
  height: 36px;
  text-align: center;
  margin-top: 10px;
 
}

.item-child-tv
{
  color: #000;
  font-size: 14px;
  margin: 0px;
  padding: 0px;
  margin-bottom: 10px;
  margin-top: 10px;
}

</style>


