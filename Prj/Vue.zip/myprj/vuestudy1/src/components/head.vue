<template>
  <div class="head-page">
    <div class="head-page-left">
      <span class="head-page-left-img icon-navigate_before"></span>
      <span class="head-page-left-text">返回</span>
    </div>

    <span class="head-page-mid">左岸阳光</span>

    <span class="head-page-right icon-more_horiz"></span>
  </div>
</template>

<script>
export default {
  name: "head"
};
</script>

<style>
@import url("../assets/fonts/style.css");
.head-page {
  width: 100%;
  height: 60px;
  background-color: #14b6f5;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.head-page-left
{
   
    display: flex;
    margin-left: 10px;
    align-items: center;
}

.head-page-left-text
{
    margin-left: 10px;
}

.head-page-left-text, .head-page-mid
{
    font-size: 16px;
    color: #fff
}

.head-page-right
{
    margin-right: 10px;
    font-size: 30px;
    color: #fff;
}
.head-page-left-img
{
    font-size: 30px;
    color: #fff;
}

</style>
