<template>
  <div class="page-view">
    <mt-header title="AIOT" class="page-view-header">
      <mt-button icon="back" slot="left" @click="goBack">返回</mt-button>
      <mt-button slot="right">分享</mt-button>
    </mt-header>
    <router-view class="page-content"></router-view>
  </div>
</template>

<script>
  export default {
    name: 'app',
    data () {
      return {}
    },
    created () {},
    methods: {
      goBack () {
        this.$router.go(-1)
      }
    }
  }
</script>
<style lang="less">
  @import '~@/common/styles/base.less';
  .page-view{
    width: 100%;
    height: 100%;
    .page-view-header{
      font-size: 16px;
    }
  }
</style>
