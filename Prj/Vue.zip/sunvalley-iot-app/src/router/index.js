import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

const LogIn = r => require.ensure([], () => r(require('@/views/log-in.vue')))
const imagesList = r => require.ensure([], () => r(require('@/views/images-list.vue')))
const routes = [{
    path: '/',
    redirect: '/login'
  }, {
    path: '/login',
    component: LogIn
  }, {
    path: '/images-list',
    component: imagesList
  }
]
const router = new Router({
  routes
})

router.beforeEach((to, from, next) => {
  next()
})
export default router
