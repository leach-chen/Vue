<template>
  <div class="login">
    <mt-button type="primary" class="login-button" @click="showToast">弹框</mt-button>
    <mt-button type="danger" class="login-button" @click="routerImg">查看图片</mt-button>
    <router-link to="images-list"><mt-button type="danger">查看图片</mt-button></router-link>
    <div class="icon icon-success"></div>
    <div style="margin-top: 25px;font-size: 35px;">{{testData | commonFormat('time')}}</div>
  </div>
</template>
<script>
  export default {
    data () {
      return {
        testData: 'Mon Jan 21 2019 16:12:31 GMT+0800 (中国标准时间)'
      }
    },
    created () {
      for (let item in this) {
        if (this.hasOwnProperty(item)) console.log(item)
      }
    },
    methods: {
      queryData () {
        this.$http.queryData({userName: 'davey', pwd: '1111'}).then(data => {
          // 返回处理
        }).catch(error => {
          // 异常处理
        })
      },
      showToast () {
        this.$toast({ message: '操作成功', position: 'bottom', duration: 1000})
      },
      routerImg () {
        this.$router.push('/images-list')
      }
    }
  }
</script>

<style lang="less" scoped>
  .login{
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    .login-button{
      width: 60%;
      margin: 15px 0;
      color: #fff;
      font-size: 20px;
    }
  }
</style>
