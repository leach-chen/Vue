<template>
<div>{{msg}}</div>    
</template>

<script type="text/javascript">

    export default{
        name:'TestVue',
        data(){
            return{
                msg:'hello'
            }
        }
    }

</script>

