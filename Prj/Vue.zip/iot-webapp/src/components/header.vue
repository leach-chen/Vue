<template>
	<div class="header-page">
		<span class="header-page-left icon icon-back"></span>
		<span class="header-page-title">Help Center</span>
		<span class="header-page-right icon icon-mail2"></span>
	</div>
</template>
<style>
	.header-page{
		width: 100%;
		height: 60px;
		background-color: #000;
		color: #FFF;
		font-size: 20px;
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding: 0 10px;
	}
	.header-page-right{
		font-size: 20px;
	}
</style>