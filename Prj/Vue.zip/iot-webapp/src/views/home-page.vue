<template>
	<div class="home-page">
		<vava-header></vava-header>
		<div class="home-page-content">
			<li v-for="(item, index) of nameList">
			<span class="content-li-name">
				{{item}}
			</span>
			<span class="icon icon-right-slide-icon"></span>
			<img src="../../public/favicon.ico"/>
			</li>
		</div>
	</div>
</template>

<script>
	import VavaHeader from '../components/header'
	export default{
		components: {VavaHeader},
		data () {
			return {
				nameList: ['VAVA Dash CAM', 'VAVA Dash Ca', 'VAVA Dash CAM', 'VAVA Dash CAM', 'VAVA Dash Ca', 'VAVA Dash CAM', 'VAVA Dash CAM', 'VAVA Dash Ca', 'VAVA Dash CAM']
			}
		},
		methods: {
			
		}
	}
</script>

<style lang="less">
	@base-color: #666;
	.home-page{
		width: 100vw;
		height: 100vh;
		background-color: #999;
		.home-page-content{
			padding-top: 5px;
			li{
				display: flex;
				align-items: center;
				justify-content: space-between;
				padding: 0 10px;
				border-top: 1px solid #f5f5f5;
				font-size: 25px;
				width: 100%;
				height: 60px;
				background-image: url(../../public/favicon.ico);
			}
		}
	}
	
</style>